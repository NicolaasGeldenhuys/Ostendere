$(document).ready(function() {

    $(".watch_later").click(function(){
        $(this).parent().removeClass(".block");
    });
});