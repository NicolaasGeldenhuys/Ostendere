# Ostendere
Welcome to the repository for Ostendere, a movie streaming platform for the masses! This will include our commits for Ostendere, thus showcasing all the progress from each member, as well as the whole team, during a specific timeframe. We are a group of 3 developers.
